
// CRUD - Create, read, update, delete

function criar() {

}

function obterMuitos() {

}

function obterUmPelaId() {

}

function deletarPelaId() {

}

function atualizarPelaId() {

}

module.exports = {
    criar,
    obterMuitos,
    obterUmPelaId,
    deletarPelaId,
    atualizarPelaId
}