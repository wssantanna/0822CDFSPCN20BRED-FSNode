
function homeViewController(req, res) { }

module.exports = homeViewController;