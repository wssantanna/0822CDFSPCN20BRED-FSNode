
const express = require('express');

const homeViewController = require('./controllers/home.controller');

const api = express();

api.get('/', homeViewController);

api.listen('1234', console.log('Servidor está no ar!'));