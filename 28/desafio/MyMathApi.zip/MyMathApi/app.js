const express = require('express')

const app = express()

// Para inicializar a aplicação execute o comando npm run producao no terminal.
app.listen(12345, function() {
    console.log('Tudo okay!')
})

// Nota: Não se esqueça de instalar as dependências em sua máquina com o comando npm install.